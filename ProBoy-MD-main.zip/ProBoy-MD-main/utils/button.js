/**
 * ProBoy-MD Button Utility (FIXED)
 * 
 * Usage:
 *   const { sendButtons, handleButtonResponse } = require('../utils/button');
 * 
 *   await sendButtons(sock, from, {
 *       text: 'Choose an option:',
 *       footer: 'ProBoy-MD',
 *       buttons: [
 *           { type: 'quick_reply', displayText: 'Alive', id: 'cmd_.alive' },
 *           { type: 'copy', displayText: 'Copy Code', copyCode: '123456' },
 *           { type: 'url', displayText: 'Website', url: 'https://proboy.vercel.app' }
 *       ]
 *   });
 */

const config = require('../config');
const giftedBtns = require('./gifted-btns');

function extractButtonIdFromMessage(msg) {
    const content = msg?.message;
    if (!content) return null;

    const direct =
        content?.buttonsResponseMessage?.selectedButtonId ||
        content?.buttonsResponseMessage?.buttonReplyMessage?.selectedId ||
        content?.buttonsResponseMessage?.id;
    if (direct) return String(direct);

    const interactive =
        content?.interactiveResponseMessage ||
        msg?.message?.interactiveResponseMessage;
    if (!interactive) return null;

    const fromBody = interactive?.id || interactive?.selectedId || interactive?.selectedButtonId;
    if (fromBody) return String(fromBody);

    const paramsJson =
        interactive?.nativeFlowResponseMessage?.paramsJson ||
        interactive?.buttonReplyMessage?.nativeFlowResponseMessage?.paramsJson;
    if (paramsJson) {
        try {
            const parsed = JSON.parse(paramsJson);
            const extracted = parsed?.id || parsed?.selected_id || parsed?.selectedId || parsed?.button_id;
            if (extracted) return String(extracted);
        } catch {}
    }

    return null;
}

/**
 * Send interactive buttons to a chat.
 * Delegates to utils/gifted-btns.js, which actually uses the `gifted-btns`
 * package to inject the binary nodes WhatsApp needs to render real buttons.
 * (Previously this reimplemented sending itself using WhatsApp's deprecated
 * legacy `buttons:[...]` format, which is why buttons stopped rendering and
 * silently degraded into plain numbered text.)
 * @param {Object} sock - WhatsApp socket
 * @param {string} jid - Chat JID
 * @param {Object} options - Button options
 */
async function sendButtons(sock, jid, options = {}) {
    return giftedBtns.sendButtons(sock, jid, options);
}

/**
 * Send a raw interactive message (any mix of native flow button types).
 * Delegates to utils/gifted-btns.js. See that file for the full button
 * catalog (quick_reply, cta_url, cta_copy, cta_call, cta_catalog,
 * single_select, send_location, and more).
 */
async function sendInteractiveMessage(sock, jid, content = {}, options = {}) {
    return giftedBtns.sendInteractiveMessage(sock, jid, content, options);
}

/**
 * Handle button response and execute command if it's a command button
 */
async function handleButtonResponse(sock, msg, extra) {
    // Get the message content
    const content = msg?.message;
    if (!content) return false;

    const buttonId = extractButtonIdFromMessage(msg);

    if (!buttonId) return false;

    // Menu shortcut buttons (space-free IDs for better reliability)
    if (buttonId === 'cmd_menu_home') {
        const menuCmd = (extra.commands || require('../handler').commands)?.get('menu');
        if (!menuCmd || typeof menuCmd.execute !== 'function') return false;
        await menuCmd.execute(sock, msg, [], extra);
        return true;
    }
    if (buttonId.startsWith('cmd_menu_cat_')) {
        const category = buttonId.replace('cmd_menu_cat_', '').trim().toLowerCase();
        const menuCmd = (extra.commands || require('../handler').commands)?.get('menu');
        if (!menuCmd || typeof menuCmd.execute !== 'function') return false;
        await menuCmd.execute(sock, msg, [category], extra);
        return true;
    }

    // Check if it's a command button (id starts with 'cmd_')
    if (!buttonId.startsWith('cmd_')) return false;

    // Extract the command (remove 'cmd_' prefix)
    let fullCommand = buttonId.slice(4);
    
    // Add prefix if missing
    const prefix = extra.config?.prefix || '.';
    const command = fullCommand.startsWith(prefix) ? fullCommand : prefix + fullCommand;

    // Get the handler commands map
    const commands = extra.commands || require('../handler').commands;
    if (!commands) return false;

    // Parse command name and args
    const args = command.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift()?.toLowerCase();
    if (!commandName) return false;

    const cmd = commands.get(commandName);
    if (!cmd || typeof cmd.execute !== 'function') {
        await extra.reply(`❌ Command not found: ${commandName}`);
        return false;
    }

    try {
        // Execute the command
        await cmd.execute(sock, msg, args, extra);
        return true;
    } catch (error) {
        console.error(`Button command error (${commandName}):`, error.message);
        await extra.reply(`❌ Error: ${error.message}`);
        return false;
    }
}

/**
 * Create a simple menu with buttons that execute commands
 */
async function sendCommandMenu(sock, jid, commandList, title = '📋 *Command Menu*') {
    const buttons = commandList.map(item => ({
        type: 'quick_reply',
        displayText: item.name,
        id: `cmd_${item.cmd.startsWith('.') ? item.cmd : '.' + item.cmd}`
    }));

    // Split into rows of 3 buttons max (WhatsApp limit)
    const chunkedButtons = [];
    for (let i = 0; i < buttons.length; i += 3) {
        chunkedButtons.push(buttons.slice(i, i + 3));
    }

    for (let i = 0; i < chunkedButtons.length; i++) {
        const chunk = chunkedButtons[i];
        await sendButtons(sock, jid, {
            text: i === 0 ? title : 'More options:',
            footer: config.botName || 'Bot',
            buttons: chunk
        });
        // Small delay to avoid rate limits
        await new Promise(r => setTimeout(r, 500));
    }
}

module.exports = {
    sendButtons,
    sendInteractiveMessage,
    handleButtonResponse,
    extractButtonIdFromMessage,
    sendCommandMenu
};
